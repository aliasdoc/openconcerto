/*
 * Project version information. Generated - do not modify.
 */
package org.olap4j.driver.xmla;
/**
  * Version information for the XMLA driver. (Generated.)
  */
class XmlaOlap4jDriverVersion {
    static final String NAME = "olap4j driver for XML/A";
    static final String VERSION = "1.0.1.500";
    static final int MAJOR_VERSION = Integer.valueOf("1");
    static final int MINOR_VERSION = Integer.valueOf("00010500");
}

// End XmlaOlap4jDriverVersion.java